-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2023 at 04:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysharedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('Admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `empID` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `NIC` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `salary` double DEFAULT NULL,
  `Role` varchar(20) NOT NULL,
  `status` varchar(20) DEFAULT 'FREE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empID`, `name`, `NIC`, `gender`, `address`, `password`, `telephone`, `salary`, `Role`, `status`) VALUES
(1, 'John Doe', '123456789', 'M', '123 Main St', 'password1', '1234567890', 50000, 'Cashier', 'Occupied'),
(13, 'Isuru', '1321312', 'M', 'Matale', 'isuru', '1122211', 35000, 'Cashier', 'Occupied'),
(21, 'Robert Johnson', '456789123', 'M', '789 Oak St', 'password3', '4567891230', 55000, 'Worker', 'FREE'),
(22, 'Naveena', '1231232', 'F', 'Matale', 'naveen', '3213', 45000, 'Worker', 'FREE'),
(23, 'shakya', '1212313', 'F', 'dambane', '123', '9769937578', 1233, 'Worker', 'FREE'),
(24, 'nirmal', '1231231', 'M', 'qweqe', '12', '12312', 23212, 'Worker', 'FREE'),
(25, 'qweq', '1231', 'M', '13133', '1312', '123123', 12312, 'Worker', 'FREE'),
(26, 'das', '213', 'F', '123', '1231', '13123', 1321, 'Worker', 'FREE');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `ID` int(11) NOT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unitPrice` double DEFAULT NULL,
  `totalPrice` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`ID`, `itemName`, `quantity`, `unitPrice`, `totalPrice`) VALUES
(1, 'sheets', 6, 9.99, 99.9),
(2, 'Product 2', 5, 4.5, 22.5),
(3, 'Product 3', 8, 7.75, 62),
(4, 'Product 4', 3, 12.99, 38.97),
(5, 'Product 5', 5, 6.25, 37.5);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `customerName` varchar(50) DEFAULT NULL,
  `customerTelephone` varchar(20) DEFAULT NULL,
  `customerEmail` varchar(100) DEFAULT NULL,
  `employeeId` varchar(11) DEFAULT NULL,
  `adObjective` varchar(100) DEFAULT NULL,
  `adTargetAudience` varchar(100) DEFAULT NULL,
  `startDate` varchar(15) DEFAULT NULL,
  `endDate` varchar(15) DEFAULT NULL,
  `bannerSize` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `bannerDescription` varchar(255) DEFAULT NULL,
  `artworkType` varchar(50) DEFAULT NULL,
  `artworkDescription` varchar(255) DEFAULT NULL,
  `totalPrice` decimal(10,2) DEFAULT NULL,
  `Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `customerName`, `customerTelephone`, `customerEmail`, `employeeId`, `adObjective`, `adTargetAudience`, `startDate`, `endDate`, `bannerSize`, `quantity`, `bannerDescription`, `artworkType`, `artworkDescription`, `totalPrice`, `Status`) VALUES
(1, 'Isuru', '1231', 'issurgayantha14@gmail.com', '12', 'Awareness', 'Students', '2023-06-07', '2023-06-08', NULL, NULL, NULL, NULL, NULL, NULL, 'ACCEPTED'),
(3, 'nirmal', '12', 'kosa@gmail.com', '1', 'Awareness', '', '12 - 7', '10 - 10', '1024*780', 0, '', 'Illustration', '', 450.00, 'DONE'),
(4, 'Naveen', '14', 'naveen@gmail.com', '1', 'Awareness', '', '14 - 5', '12 - 5', '1024*780', 0, '', 'Illustration', '', 450.00, ''),
(6, 'kalana', '1312', 'kalana@gmail.com', '1', 'Marketing', 'students', '2 - 5', '3 - 5', '', 0, '', '', '', 450.00, 'DONE'),
(12, 'isuru', '123', 'isueddf', '3', 'Awareness', '12', '2 - 5', '3 - 6', '', 0, '', '', '', 450.00, ''),
(14, 'pasan', '3132', 'pasan@gmail.com', '15', 'Awareness', 'qeqw', '1 - 5', '3 - 5', '', 0, '', 'Graphic Design', 'adqdw', 450.00, ''),
(15, 'qweq', 'qewqe', 'qweq', '12', 'Awareness', 'කවනවයට', '12 - 4', '15 - 4', '', 0, '', 'Motion Graphics', 'jkj', 450.00, ''),
(17, 'Sewmini', '0769937578', 'sewmini@gmail.com', '14', 'Charity', 'Students', '3 - 6', '15 - 6', '1024*780', 4, 'this is a baner of class regitration', 'Graphic Design', 'this is illustration of a lecturer', 450.00, ''),
(18, 'lnlj', '231', '1323@gmail.com', '20', '', '', '', '', '', 0, '', 'Graphic Design', 'adasd', 450.00, 'ACCEPTED'),
(19, 'vinuka', '12312', 'vinuka.oveen@gmail.com', '3', 'Awareness', '12', '2 - 6', '4 - 6', '', 0, '', '', '', 450.00, 'DONE'),
(20, 'kiri saman', '4545646', 'marasinghepasan11@gmail.com', '14', 'Marketing', '31231', '2 - 6', '4 - 6', '', 0, '', '', '', 450.00, 'DONE'),
(21, 'keri Kiri saman', '131233', 'maresinghapasan11@gmail.com', '15', '', '', '', '', '1024*780', 3, 'sadasdada', '', '', 450.00, 'DONE');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplierID` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `orders` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplierID`, `name`, `telephone`, `address`, `gender`, `email`, `orders`) VALUES
(1, 'Supplier 1', '1234567890', '123 Main St', 'M', 'supplier1@example.com', 'Order 1, Order 2'),
(2, 'Supplier 2', '9876543210', '456 Elm St', 'F', 'supplier2@example.com', 'Order 3, Order 4'),
(3, 'Supplier 3', '5555555555', '789 Oak St', 'M', 'supplier3@example.com', 'Order 5'),
(4, 'Supplier 4', '9999999999', '321 Maple Ave', 'F', 'supplier4@example.com', 'Order 6, Order 7'),
(5, 'Supplier 5', '8888888888', '654 Pine Rd', 'M', 'supplier5@example.com', 'Order 8'),
(7, 'Shakya', '123131', 'ganja handiya', 'M', 'shakya@gmail.com', 'half sheets');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`empID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplierID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `empID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplierID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
